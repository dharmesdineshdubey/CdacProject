package cdacProject.service;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.util.Properties;
import java.util.Scanner;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cdacProject.DAO.LoginDetailsDao;
import cdacProject.model.LoginUser;



@Service
public class LoginDetailsService 
{
    @Autowired
   private LoginDetailsDao loginDetails;
    
    public int insertUser(LoginUser data)
    {
    	return loginDetails.insert(data);
    }
    
    
    public LoginUser getUserObj(int userid)
    {
    	return loginDetails.getByUser(userid);
    	
    }
    
    public void passUpdate(LoginUser data)
    {
    	loginDetails.updatepass(data);
    	
    }
    
    public void sendAttach(String msg, String subject, String to, String from, String location) 
    {
    	//variable for gmail
    	String host="smtp.gmail.com";
    	
    	//get the system properties
    	Properties properties = System.getProperties();
    	System.out.println("Properties "+properties);
    	
    	//setting important information to properties object
    	
    	//host set
    	properties.put("mail.smtp.host", host);
    	properties.put("mail.smtp.port", 465);
    	properties.put("mail.smtp.ssl.enable", "true");
    	properties.put("mail.smtp.auth", "true");
    	
    	//step 1: to get session object
    	
    	Session session = Session.getInstance(properties, new Authenticator() {

			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				
				return new PasswordAuthentication("dharmeshdubey29101995@gmail.com", "jlkmoprxdxrjuvkd");
			}
    		
    		
		});
    	
    	session.setDebug(true);
    	
    	//step 2: to get session object
    	MimeMessage m = new MimeMessage(session);
    	
    	try 
    	{
    	   //from email	
    		m.setFrom(from);
    		
    	  //adding recipient to message
    		m.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
    		
    	 //adding subject 
    		m.setSubject(subject);
    		
    	//adding attachment to message
    	//file path	
    		String path = location; 
    		
    		MimeMultipart mimeMultipart = new MimeMultipart();
    		
    		
    		MimeBodyPart textMime = new MimeBodyPart();
    		
    		MimeBodyPart  fileMime = new MimeBodyPart();
    		
    		try {
    			textMime.setText(msg);
    			
    			File file= new File(path);
    			
    			fileMime.attachFile(file);
    			
    		     mimeMultipart.addBodyPart(textMime);
    		     
    		     mimeMultipart.addBodyPart(fileMime);
				
			} 
    		catch (Exception e) {
				// TODO: handle exception
			}
    		
    		
    		m.setContent(mimeMultipart);
    		
    		
    		
    	//send
    		
    	//send 3 :send the message using Transport class
    		
    		Transport.send(m);
    		
    		System.out.println("Sent Success...........");
    		
		 } 
    	catch (Exception e) 
    	{
			e.printStackTrace();
		}
 		
 	}
    
    
   /* public String EncrypDecrypt(String data1)
    {
            System.out.println("Enter in EncrypttoDecrypt class-------------------------------");
            //Creating a Signature object
            System.out.println("Creating a Signature object");
            try {
                Signature sign = Signature.getInstance("SHA256withRSA");
                System.out.println("sign"+sign);
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }

            //Creating KeyPair generator object
            System.out.println("Creating KeyPair generator object using RSA");
            KeyPairGenerator keyPairGen = null;
            try {
                keyPairGen = KeyPairGenerator.getInstance("RSA");
                System.out.println("keyPairGen: "+keyPairGen);
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }

            //Initializing the key pair generator
            System.out.println("Initializing the key pair generator");
            keyPairGen.initialize(2048);

            //Generate the pair of keys
            System.out.println("Generate the pair of keys");
            KeyPair pair = keyPairGen.generateKeyPair();
            System.out.println("pair: "+pair);

            //Getting the public key from the key pair
            System.out.println("Getting the public key from the key pair");
            PublicKey publicKey = pair.getPublic();
            System.out.println("publicKey: "+publicKey);

            //Creating a Cipher object
            System.out.println("Creating a Cipher object");
            Cipher cipher = null;
            try {
                cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            } catch (NoSuchPaddingException e) {
                throw new RuntimeException(e);
            }

            //Initializing a Cipher object
            System.out.println("Initializing a Cipher object using publicKey---- ");
            try {
                cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            } catch (InvalidKeyException e) {
                throw new RuntimeException(e);
            }

            System.out.println(data1);
            //Add data to the cipher
            Scanner s=new Scanner(System.in);
            String str=s.nextLine();
            byte[] input = data1.getBytes();
            cipher.update(input);

            //encrypting the data
            System.out.println("encrypting the data using cipherText: ");
            byte[] cipherText = new byte[0];
            try {
                cipherText = cipher.doFinal();
                System.out.println("cipherText: "+cipherText);
            } catch (IllegalBlockSizeException e) {
                throw new RuntimeException(e);
            } catch (BadPaddingException e) {
                throw new RuntimeException(e);
            }
            try {
                System.out.println( new String(cipherText, "UTF8"));
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException(e);
            }

            //Initializing the same cipher for decryption
            System.out.println("Initializing the same cipher for decryption using Cipher.DECRYPT_MODE, pair.getPrivate()");
            try {
                cipher.init(Cipher.DECRYPT_MODE, pair.getPrivate());
            } catch (InvalidKeyException e) {
                throw new RuntimeException(e);
            }

            //Decrypting the text
            System.out.println("Decrypting the text");
            byte[] decipheredText = new byte[0];
            System.out.println("decipheredText: "+decipheredText);
            try {
                decipheredText = cipher.doFinal(cipherText);
                System.out.println("decipheredText using cipher.doFinal(cipherText): "+decipheredText);
            } catch (IllegalBlockSizeException e) {
                throw new RuntimeException(e);
            } catch (BadPaddingException e) {
                throw new RuntimeException(e);
            }
            System.out.println("The deciphered Text is: ");
            System.out.println(new String(decipheredText));
            
            String PublicKeystring = publicKey.toString();
            return PublicKeystring;
            
    }*/
            
            //CreatingDigitalSign
    
         /*   public String CreatingDigitalSign(String data2)
            {
            
             System.out.println("Inside CreatingDigitalSignature class------------------------------");

            //Creating KeyPair generator object
            System.out.println("Creating KeyPair generator object using RSA");
            KeyPairGenerator keyPairGen1 = null;
            try {
                keyPairGen1 = KeyPairGenerator.getInstance("RSA");
                System.out.println("keyPairGen: "+keyPairGen1);
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }

            //Initializing the key pair generator
            System.out.println("Initializing the key pair generator");
            keyPairGen1.initialize(2048);

            //Generate the pair of keys
            System.out.println("Generate the pair of keys");
            KeyPair pair1 = keyPairGen1.generateKeyPair();
            System.out.println("pair: "+pair1);

            //Getting the private key from the key pair
            System.out.println("Getting the private key from the key pair");
            PrivateKey privKey = pair1.getPrivate();
            System.out.println("privKey: "+privKey);

            //Creating a Signature object
            System.out.println("Creating a Signature object");
            Signature sign = null;
            try {
                sign = Signature.getInstance("SHA256withRSA");
                System.out.println("sign: "+sign);
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }

            //Initialize the signature
            System.out.println("Initialize the signature using privKey code is sign.initSign(privKey) ");
            try {
                sign.initSign(privKey);
            } catch (InvalidKeyException e) {
                throw new RuntimeException(e);
            }
            //Scanner s1=new Scanner(System.in);
            System.out.println(data2);
           // String str=s.nextLine();
            byte[] bytes = data2.getBytes();
            System.out.println("bytes: "+bytes);

            //Adding data to the signature
            System.out.println("Adding data to the signature using sign.update(bytes)--- ");
            try {
                sign.update(bytes);
            } catch (SignatureException e) {
                throw new RuntimeException(e);
            }

            //Calculating the signature
            System.out.println("Calculating the signature");
            byte[] signature = new byte[0];
            try {
                signature = sign.sign();
                System.out.println("signature: "+signature);
            } catch (SignatureException e) {
                throw new RuntimeException(e);
            }

            //Printing the signature
            System.out.println("Printing the signature");
            try {
                System.out.println("Digital signature for given text: "+new String(signature, "UTF8"));
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException(e);
        }
            String privateKeyString= privKey.toString();
          return privateKeyString;
      
    }    */
    
	
    
    
    
}
